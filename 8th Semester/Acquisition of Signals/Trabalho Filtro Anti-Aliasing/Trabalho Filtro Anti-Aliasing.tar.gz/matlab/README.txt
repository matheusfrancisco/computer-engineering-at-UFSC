DEC 7561 - Sistemas de Aquisição de Sinais
Tiago Oliveira Weber

O arquivo com as configurações e execução é o test_serial_readwrite.m

Atalhos:

- Para trocar a tensão gerada pelo PWM, tecle "v" e logo após a tensão desejada;
- Para sair do programa, tecle "x". Caso não funcione, faça CTRL+C repetidas vezes no terminal.
