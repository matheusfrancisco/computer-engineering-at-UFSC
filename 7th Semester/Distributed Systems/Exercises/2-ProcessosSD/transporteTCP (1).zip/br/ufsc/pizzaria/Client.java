package br.ufsc.pizzaria;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {
		int serverPort = 4567;
		Socket conn = null;
		
		InetAddress serverAddress;
		try {
			serverAddress = InetAddress.getByName("localhost");
			conn = new Socket(serverAddress, serverPort);
			
			DataOutputStream out = new DataOutputStream(conn.getOutputStream());
			DataInputStream in = new DataInputStream(conn.getInputStream());
			
			for (int i = 0; i < 10; i++) {
				
				out.writeUTF("Cliente: " + i);
			
				String recebida = in.readUTF();
			
				System.out.println(recebida);
			}
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (IOException e) {
				System.err.println("IO Closing Conn: " + e.getMessage());
			}
		}

	}

}
