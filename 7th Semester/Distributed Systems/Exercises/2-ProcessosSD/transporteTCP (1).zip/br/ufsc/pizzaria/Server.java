package br.ufsc.pizzaria;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	// Socket conn;

	public static void main(String[] args) {

		int serverPort = 4567;
		Socket conn = null;

		try {
			ServerSocket serverSocket = new ServerSocket(serverPort);
			System.out.println("Iniciando server...");
			conn = serverSocket.accept();

			DataOutputStream out = new DataOutputStream(conn.getOutputStream());
			DataInputStream in = new DataInputStream(conn.getInputStream());

			for (int i = 0; i < 10; i++) {

				String mensagem = in.readUTF();

				System.out.println(mensagem);

				out.writeUTF("Servidor para " + mensagem);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (IOException e) {
				System.err.println("IO Closing Conn: " + e.getMessage());
			}
		}

	}

}
