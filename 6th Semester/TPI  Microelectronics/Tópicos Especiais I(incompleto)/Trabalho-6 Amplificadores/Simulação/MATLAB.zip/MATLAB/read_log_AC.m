function [meas] = read_log_AC ()

%Abre arquivo na pasta localizada no diret�rio superior chamada LTSPICE
fid = fopen('generated_netlist_AC.log', 'r');

line  = fgetl(fid);
    while(~feof(fid))
        line = fgets(fid);
        elements = strsplit(line,{' ','='});
        if (strcmp(elements(1),'gain1hz:'))
            elements = strsplit(char(elements(3)),{'(','dB'});
            meas = str2num(elements{2});
        break;
        end  
    end

fclose(fid);


end